import datetime
import sqlalchemy
from flask_wtf import FlaskForm
from sqlalchemy import orm
from wtforms import StringField, TextAreaField, BooleanField, SubmitField
from wtforms.validators import DataRequired

from .db_session import SqlAlchemyBase

class MModels(SqlAlchemyBase):
    __tablename__ = 'mmodels'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    
    p1 = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    p2 = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    p3 = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    p4 = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    p5 = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    p6 = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    user_id = sqlalchemy.Column(sqlalchemy.Integer, 
                                sqlalchemy.ForeignKey("users.id"))    
    user = orm.relation('User')
    
class MModelsForm(FlaskForm):
    name = StringField('Заголовок', validators=[DataRequired()])
    p1 = TextAreaField("P1")
    p2 = TextAreaField("P1")
    p3 = TextAreaField("P1")
    p4 = TextAreaField("P1")
    p5 = TextAreaField("P1")
    p6 = TextAreaField("P1")
    submit = SubmitField('Применить')